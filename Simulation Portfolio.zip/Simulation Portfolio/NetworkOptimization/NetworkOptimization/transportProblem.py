from pyomo.environ import *
import pandas as pd


# initialize optimization model
model = ConcreteModel()


# read plant data
dfS = pd.read_excel('plants.xlsx', index_col=0, header=None)
dfS = dfS.index
supplierList = dfS.tolist()

# read demand data
dfD = pd.read_excel('demandUnits.xlsx', index_col=0, header=None)
dfD = dfD.index
demandList = dfD.tolist()


# define sets and parameters
model.i = Set(initialize= supplierList, doc='plants')
model.j = Set(initialize= demandList, doc='demand units')

# plants
model.a = Param(model.i, 
                initialize={'Dortmund':100, 
                            'Berlin':100}, 
                doc='capacity of plant i')

# demand units
model.b = Param(model.j, 
                initialize={'Aachen':75,
                            'Leverkusen':25, 
                            'Dresden':100}, 
                doc='demand for city j')

# dict of distances
distanceTable = {
    ('Dortmund', 'Aachen') : 160,
    ('Dortmund', 'Leverkusen') : 76,
    ('Dortmund', 'Dresden') : 515,
    ('Berlin', 'Aachen') : 638,
    ('Berlin', 'Leverkusen') : 555,
    ('Berlin', 'Dresden') : 193,
    }


# pass set 'i' and 'j' in the distanceTable
model.d = Param(model.i, model.j, initialize=distanceTable, doc='Distances in kilometers')

# freight cost
model.f = Param(initialize=90, doc='Freight in dollars per case per thousands of miles')
def c_init(model, i, j):
    return model.f * model.d[i,j] / 1000
model.c = Param(model.i, model.j, initialize=c_init, doc='Transport cost in thousands of dollars per case')


# define decision variables
model.x = Var(model.i, model.j, bounds=(0.0, None), doc='Shipment quantities in case')


# C1: Set supply limit for plants
def supply_rule(model, i):
    return sum(model.x[i,j] for j in model.j) <= model.a[i]
model.supply = Constraint(model.i, rule=supply_rule, doc='Observe supply limit at plant i')

# C2: Satisfy demand 
def demand_rule(model, j):
    return sum(model.x[i,j] for i in model.i) >= model.b[j]
model.demand = Constraint(model.j, rule=demand_rule, doc='Satisfy demand at demand unit j')


# objective function
def objective_rule(model):
    return sum(model.c[i,j]*model.x[i,j] for i in model.i for j in model.j)
model.objective = Objective(rule=objective_rule, sense=minimize, doc='Define objective function')


# display of output
def pyomo_postprocess(options=None, instance=None, results=None):
    model.x.display()
    #print("==============================================")
    #model.c.display()
    #print("==============================================")
    #model.objective.display()


if __name__ == '__main__':
    from pyomo.opt import SolverFactory
    import pyomo.environ
    opt = SolverFactory('glpk')
    results = opt.solve(model)
    
    results.write()
    print("\nDisplaying Solution\n" + '='*60)
    pyomo_postprocess(None, model, results)
    

## TODO: write the optimal values to an excel file

# pass the optimized decision variables to a DataFrame (kind of works...)
optimal_values = [value(model.x[keys]) for keys in model.x]
corresponding_keys = [keys(model.x[lower]) for lower in model.x]


df = pd.DataFrame(optimal_values)

