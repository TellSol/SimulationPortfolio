# Setting up a connection from python to AnyLogic


def sumTwoValues(a, b):
    print(a+b)

sumTwoValues(1,2)